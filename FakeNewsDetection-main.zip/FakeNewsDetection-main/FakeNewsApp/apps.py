from django.apps import AppConfig


class FakenewsappConfig(AppConfig):
    name = 'FakeNewsApp'
